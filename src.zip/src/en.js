const en = {
  created: 'created Message',
  import: 'import Excel'
}

export default en
