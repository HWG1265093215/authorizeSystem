import { createApp } from 'vue'
import App from './App.vue'
// 路由
//import routerConfig from './routerConfig/router.js'
//import {ElButton,ElContainer,ElHeader,ElAside,ElMain,ElFooter,ElMenu,ElSubMenu,ElMenuItem,ElMenuItemGroup}  from 'element-plus';
//import 'element-plus/dist/index.css'
//import 'element-plus/dist/index.css'

//import 'element-plus/lib/theme-chalk/index.css';
 

const app = createApp(App);
// app.use(ElButton);
// app.use(ElContainer);
// app.use(ElHeader);
// app.use(ElAside);
// app.use(ElMain);
// app.use(ElFooter);
// app.use(ElMenu);

// app.use(ElSubMenu);
// app.use(ElMenuItem);
// app.use(ElMenuItemGroup);
//app.use(routerConfig)
  app.mount('#app');
