<template>
    <div>
        <h1>详情页</h1>
    </div>
</template>
