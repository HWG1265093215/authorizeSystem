<template>
    <div>
        <h1>首页  {{query}}</h1>
    </div>
</template>
<script>
import { ref, reactive, watch } from 'vue'
export default {
  name: 'Home',
  setup: function () {
    const query = ref(null)
    console.log()
    function setquery (prequery) {
      console.log('开始赋值', prequery)
      this.query = prequery
    }

    return {
      query, setquery
    }
  },
  // beforeRouteEnter:function(to,from,next)
  // {
  //     next(vm => {
  //         vm.setquery(to.query.lang);
  //     })
  // },
  // beforeRouteUpdate:function(to,from,next)
  // {
  //     this.query=to.query.lang;
  //     console.log("触发了.....");
  //     next();
  // }
  activated: function () {
    this.query = this.$route.query.lang
    console.log('触发', this.$route.query.lang)
  },
  // created:function()
  // {
  //     console.log("初始加载...");
  // }
  route: {
    data: function (transition) {
      console.log(this.$route.query.lang)
    }
  }
}
</script>
