const zh = {
  created: '创建成功',
  import: '导入成功'
}

export default zh
