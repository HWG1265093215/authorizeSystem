import { createRouter, createWebHistory, createWebHashHistory } from 'vue-router'

const details = () => import('../components/Details.vue')
const Home = () => import('../components/Home.vue')
const person = () => import('../components/Person.vue')
const hello = () => import('../components/HelloWorld.vue')

var routers = [
  {
    path: '/',
    component: hello
  },
  {
    path: '/Home',
    component: Home,
    name: 'Home'
  },
  {
    path: '/details',
    component: details

  },
  {
    path: '/person',
    component: person
  },
  {
    path: '/:pathMatch(.*)',
    component: () => import('../components/error.vue')
  }
]

const routerConfig = createRouter({
  routes: routers,
  history: createWebHistory(),
  saveScrollPosition: true,
  scrollBehavior (to, from, savedPosition) {
    if (savedPosition) {
      console.log(savedPosition)
      return savedPosition
    } else {
      return { x: 0, y: 0 }
    }
  },
  transitionOnload: true
})

export default routerConfig
